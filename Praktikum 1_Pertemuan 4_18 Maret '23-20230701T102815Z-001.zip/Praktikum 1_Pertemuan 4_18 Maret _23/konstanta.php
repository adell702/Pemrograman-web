<?php
define ("NAMA", "Achmad Solichin");
define ("NILAI", 90);

//NAMA = "Muhammad"; //akan menyebabkan error
echo "Nama : " . NAMA;
echo "<br>Nilai : " . NILAI;
?>