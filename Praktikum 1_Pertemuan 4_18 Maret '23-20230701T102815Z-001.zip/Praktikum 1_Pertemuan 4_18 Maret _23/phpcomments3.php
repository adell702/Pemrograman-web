<!DOCTYPE html>
<html>
<body>

<?php
//You can also use comments to leave out parts of a code line
$x = 5 /* + 15 */ + 5;
echo $x;
?>

</body>
</html>