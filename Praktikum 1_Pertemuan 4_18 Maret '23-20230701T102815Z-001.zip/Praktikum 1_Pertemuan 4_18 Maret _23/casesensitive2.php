<DOCTYPE html>
<html>
<body>

<?php
$color = "red";
$COLOR = "blue";
$coLOR = "white";
echo "My car is " . $color . "<br>";
echo "My house is " . $COLOR . "<br>";
echo "My boat is " . $coLOR . "<br>";
?>

</body>
</html>