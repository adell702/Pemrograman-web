<!DOCTYPE html>
<html>
<body>

<?php
ECHO "Hell Boy!<br>";
echo "Hello Girl!<br>";
ECHO "Hello Gay!<br>";
?>

</body>
</html>